#readme
we udate this file a lot so check our GitHub everyday incase of a update if you don't
this will happin
no friends
no party invites
no games but party royale
no body online
no skins in games
no text chat
no party chat (only game chat)
can't buy anything from Shop unless you have the shop plunge
if you don't have shop plunge go to our GitHub profile and look at our project called plunges for FoatNightOG
or foatnight Hybird
we will have to update this so check our GitHub everyday